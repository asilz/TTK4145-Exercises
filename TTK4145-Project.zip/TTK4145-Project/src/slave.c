#include <log.h>
#include <netinet/ip.h>
#include <pthread.h>
#include <signal.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

int main(void)
{
    int master_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    int elevator_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    struct sockaddr *addr;
    struct sockaddr_in addr_in;
    addr_in.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr_in.sin_port = htons(15657);
    addr_in.sin_family = AF_INET;

    addr = (struct sockaddr *)&addr_in;
    struct timeval time;
    time.tv_sec = UINT32_MAX;
    time.tv_usec = 0;

    int err = setsockopt(master_socket, SOL_SOCKET, SO_RCVTIMEO, &time, sizeof(time));
    if (err)
    {
        return err;
    }
    err = setsockopt(elevator_socket, SOL_SOCKET, SO_RCVTIMEO, &time, sizeof(time));
    if (err)
    {
        return err;
    }

    err = connect(master_socket, addr, sizeof(addr_in));
    if (err)
    {
        return err;
    }
    err = connect(elevator_socket, addr, sizeof(addr_in));
    if (err)
    {
        return err;
    }

    int8_t buf[4];
    while (1)
    {
        recv(master_socket, buf, sizeof(buf), MSG_NOSIGNAL);
        send(elevator_socket, buf, sizeof(buf), MSG_NOSIGNAL);
        if(buf[0] > 5) {
            recv(elevator_socket, buf, sizeof(buf), MSG_NOSIGNAL);
            send(master_socket, buf, sizeof(buf), MSG_NOSIGNAL);
        }

        for (target_floor = 0; target_floor < FLOOR_COUNT; ++target_floor)
        {
            if (cab_buttons[target_floor])
            {
                pthread_mutex_lock(&context.lock);
                context.floor_states[target_floor] |= FLOOR_FLAG_LOCKED;
                pthread_mutex_unlock(&context.lock);
                current_state = ELEVATOR_STATE_MOVING;
                if (target_floor > current_floor)
                {
                    send(tcp_socket, &msg_motor_up, sizeof(msg_motor_up), 0);
                }
                if (target_floor < current_floor)
                {
                    send(tcp_socket, &msg_motor_down, sizeof(msg_motor_down), 0);
                }
                break;
            }
        }
    }
}
